package ksplauncher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;
import javax.swing.JInternalFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Panel;
import java.awt.Canvas;
import javax.swing.JDesktopPane;
import java.awt.ScrollPane;
import com.jgoodies.forms.factories.DefaultComponentFactory;

public class ohno extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ohno dialog = new ohno();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ohno() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(ohno.class.getResource("/com/sun/javafx/scene/control/skin/caspian/dialog-error.png")));
		setTitle("Oh No!");
		setBounds(100, 100, 374, 115);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("");
			lblNewJgoodiesTitle.setIcon(new ImageIcon(ohno.class.getResource("/javax/swing/plaf/metal/icons/ocean/error.png")));
			contentPanel.add(lblNewJgoodiesTitle);
		}
		{
			JLabel lblNewLabel = new JLabel("Steam KSP Install Not Detected! Is KSP Installed?");
			contentPanel.add(lblNewLabel);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Check Steam");
				okButton.setActionCommand("ok");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("The Shitfuck2");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	private void setIconImage(Image image) {
		// TODO Auto-generated method stub
		
	}

}
