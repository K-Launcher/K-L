package ksplauncher;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import com.jgoodies.forms.factories.DefaultComponentFactory;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class ohnoII extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ohnoII dialog = new ohnoII();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ohnoII() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ohnoII.class.getResource("/com/sun/javafx/scene/control/skin/caspian/dialog-error.png")));
		setTitle("Oh No!");
		setBounds(100, 100, 392, 115);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("Galaxy Of Games KSP Install Not Detected! Is KSP Installed?");
			lblNewJgoodiesTitle.setIcon(new ImageIcon(ohnoII.class.getResource("/com/sun/java/swing/plaf/windows/icons/Error.gif")));
			contentPanel.add(lblNewJgoodiesTitle);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Check Galaxy Of Games");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("The Shitfuck2");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	private void setIconImage(Image image) {
		// TODO Auto-generated method stub
		
	}

}
