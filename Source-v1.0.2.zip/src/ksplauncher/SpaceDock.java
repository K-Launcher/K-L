package ksplauncher;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.io.IOException;
import java.net.URL;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import javax.swing.JSpinner;

public class SpaceDock extends JFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SpaceDock frame = new SpaceDock();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SpaceDock() {
		
		JEditorPane jEditorPane = new JEditorPane();
		setTitle("Meme Center");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		
		JEditorPane JEditorPane = new JEditorPane();
		getContentPane().add(JEditorPane, BorderLayout.CENTER);
		
		JEditorPane editorPane = new JEditorPane();
	      jEditorPane.setEditable(false);   
	      URL url= SpaceDock.class.getResource("MEMES.htm");

	      try {   
	         jEditorPane.setPage(url);
	      } catch (IOException e) { 
	         jEditorPane.setContentType("text/html");
	         jEditorPane.setText("<html>Page not found.</html>");
	      }
	}

}
