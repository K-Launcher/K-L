package ksplauncher.DRPC;

import club.minnced.discord.rpc.*;
import club.minnced.discord.rpc.DiscordEventHandlers.*;

public class RPC2 {
     private static String discordID = "1072592217799151666";
     private static DiscordRichPresence DRPC = new DiscordRichPresence();
     private static DiscordRPC  discordRPC = DiscordRPC.INSTANCE;
     
    public static void startRPC();
       DiscordEventHandlers evehand = new DiscordEventHandlers();
       eventHandlers.dissocnected 
	}
}
