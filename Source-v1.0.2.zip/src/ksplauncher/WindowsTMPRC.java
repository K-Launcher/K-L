package ksplauncher;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.Toolkit;
import java.awt.FlowLayout;

public class WindowsTMPRC {

	private JFrame frmAltksplauncher;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WindowsTMPRC window = new WindowsTMPRC();
					window.frmAltksplauncher.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public WindowsTMPRC() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAltksplauncher = new JFrame();
		frmAltksplauncher.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Administrator\\eclipse-workspace\\KSP-LAUNCHER\\K-L icon.png"));
		frmAltksplauncher.setTitle("K- Launcher (A KSP Launcher)");
		frmAltksplauncher.setBounds(100, 100, 569, 360);
		frmAltksplauncher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JTextArea ChangeLog = new JTextArea();
		ChangeLog.setLineWrap(true);
		ChangeLog.setText("Note:\r\nTHIS LAUNCHER IS UNOFFICAL AND MADE IN JAVA.\r\nDO NOT CLAIM THIS IS A OFFICAL LAUNCHER BY HARVESTER,SQAUD OR PRIVATE DIVISION\r\nLauncher Change Log:\r\nv1.0.1 compiled: 4th Feb 2023\r\nChanges:\r\n-Downgraded to Java 5 update 13. Thus Windows 98,Neptune,2000,Whisler And Me are partly supported\r\n- Spelling Mistakes\r\nAdditions:\r\nNone\r\nBug Fixes:\r\nNone\r\nNote:\r\nA GITHUB NOW EXISTS! THE SOFTWARE IS NOW UNDER GPLv3 (I Hope I Don't regret that)\r\nbtw the url:https://github.com/K-Launcher/K-L\r\nv1.0.0 compiled: 2nd Feb 2023\r\nInitial relase.");
		ChangeLog.setEditable(false);
		frmAltksplauncher.getContentPane().add(ChangeLog, BorderLayout.CENTER);
		
		JPanel buttonPane = new JPanel();
		frmAltksplauncher.getContentPane().add(buttonPane, BorderLayout.SOUTH);
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		
		JButton btnSteamLaunch = new JButton("Steam Launch");
		btnSteamLaunch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			        try {
			            Runtime runTime = Runtime.getRuntime();
			            
			            String executablePath;
			            executablePath = "C:\\Program Files (x86)\\Steam\\SteamApps\\common\\Kerbal Space Program\\KSP_x64.exe";
			            
			            runTime.exec(executablePath);
			        } catch (IOException o) {
	                   ohno err = new ohno();
	                   err.show();
			        }
				}
		});
		
		/**JButton btnNewButton = new JButton("Mods");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                SpaceDock Mods = new SpaceDock();
                Mods.show();
			}
		});
		buttonPane.add(btnNewButton);**/
		buttonPane.add(btnSteamLaunch);		
		
		JButton btnGOGLaunch = new JButton("Galaxy Of Games Launch");
		btnGOGLaunch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			        try {
			            Runtime runTime = Runtime.getRuntime();
			            
			            String executablePath;
			            executablePath = "C:\\Program Files (x86)\\GOG Galaxy\\Games\\Kerbal Space Program\\KSP_x64.exe";
			            
			            runTime.exec(executablePath);
			        } catch (IOException o) {
	                   ohnoII errII = new ohnoII();
	                   errII.show();
			        }
			}
		});
		buttonPane.add(btnGOGLaunch);
	}

	protected void dispose() {
		// TODO Auto-generated method stub
		
	}

	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
